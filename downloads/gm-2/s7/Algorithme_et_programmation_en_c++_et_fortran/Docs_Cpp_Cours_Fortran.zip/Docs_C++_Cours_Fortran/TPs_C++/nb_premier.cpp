#include <iostream>
#include<cmath>
using namespace std;

int main ()
{
    int i,n;
    cout<<"Donner un entier: ";
    cin>>n;
    i=2;
    while ((i<=sqrt(n)) && (n%i!=0))
        i++;
    if (i>sqrt(n) && n>1)
        cout<<n<<" est premier";
    else
        cout<<n<<" n'est pas premier";

}
