#include <iostream>
#include <cstring>
using namespace std;
main()
{
char s[31];
cout<<"Donner la chaine s :";
cin>>s;
int i = 0, j = strlen(s) - 1;
while (s[i] == s[j] && i < j)
i++, j--;
if (i >= j)
cout<<"La chaine \""<<s<<"\" est plaindrome";
else
cout<<"La chaine "<<s<<" n'est pas plaindrome";
}
