#include <iostream>
#include <cstring>
using namespace std;
main()
{
int T[100];
int n,i,j,temp;
cout<<"Donner la taille du tableau";
cin>>n;
cout<<"Saisir les elements du tableau :"<<endl;
for(i=0;i<n;i++)
  cin>>T[i];
for(i=0;i<n-1;i++)
    for(j=i+1;j<n;j++)
      if (T[j]>T[i])
        { temp=T[i];T[i]=T[j]; T[j]=temp; }
cout<<"Voici le tableau trie";
for(i=0;i<n;i++)
    cout<<T[i]<<" ";
}
