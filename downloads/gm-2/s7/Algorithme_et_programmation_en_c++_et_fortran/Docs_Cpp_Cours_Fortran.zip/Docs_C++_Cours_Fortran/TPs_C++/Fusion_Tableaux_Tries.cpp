#include <iostream>
using namespace std;
main()
{
int n1,n2,i,j,k;
cout<<"Dimension du tableau A  : ";
cin>>n1;
int A[n1];
cout<<"Entrer les elements de A dans l'ordre croissant :\n";
 for (i=0; i<n1; i++)
    {
     cout<<"Element A["<<i<<"]: ";
     cin>>A[i];
    }
cout<<"Dimension du tableau B  : ";
cin>>n2;
int B[n2];
cout<<"Entrer les elements de B dans l'ordre croissant :\n";
 for (j=0; j<n2; j++)
    {
     cout<<"El�ment B["<<j<<"]: ";
     cin>>B[j];
    }

int C[n1+n2];

 i=0; j=0; k=0;
 while ((i<n1) && (j<n2))
        if(A[i]<B[j])
            {
             C[k]=A[i];
             k++;
             i++;
            }
        else
            {
             C[k]=B[j];
             k++;
             j++;
            }
 /* Si IA ou IB sont arriv�s � la fin de leur tableau, */
 /* alors copier le reste de l'autre tableau.          */
 while (i<n1)
        {
         C[k]=A[i];
         k++;
         i++;
        }
 while (j<n2)
        {
         C[k]=B[j];
         k++;
         j++;
        }

 /* Edition du r�sultat */
 cout<<"Tableau FUSION :"<<endl;
 for (k=0; k<n1+n2; k++)
     cout<< C[k]<<" ";


}
