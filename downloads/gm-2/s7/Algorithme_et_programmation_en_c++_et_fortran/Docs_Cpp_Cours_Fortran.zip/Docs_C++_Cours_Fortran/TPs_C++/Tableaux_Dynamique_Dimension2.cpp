#include <iostream>
#include<iomanip>
using namespace std;
void Liberer_Tab(int**t,int nLignes){

  for (int i=0; i < nLignes; i++)
    delete[] t[i];
  delete[] t;
}
 main(){
  int **M;
  int n;
  int m;
  cout << "Nombre de colonnes : ";  cin >> m;
  cout << "Nombre de lignes : ";  cin >> n;
  /* Allocation dynamique */
  M = new int* [ n ];
  for (int i=0; i < n; i++)
    M[i] = new int[ m ];
  /* Initialisation */
  for (int i=0; i < n; i++)
    for (int j=0; j < m; j++)
      M[i][j] = i*j;
  /* Affichage */
  for (int i=0; i < n; i++) {
    for (int j=0; j < m; j++)
      cout <<setw(4)<< M[i][j] << " ";
    cout << endl;
  }

  Liberer_Tab(M,n);
}

