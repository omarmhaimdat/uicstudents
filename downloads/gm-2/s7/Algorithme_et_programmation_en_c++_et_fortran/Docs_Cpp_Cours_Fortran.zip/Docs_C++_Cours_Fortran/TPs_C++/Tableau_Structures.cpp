#include <iostream>
#include <cstring>
using namespace std;
main()
{
    struct etudiant{
    int num;
    char nom[15];
    float moy;
};
    struct etudiant T[3];
    int i;
    for(i=0;i<3;i++)
    {
        cout<<"Donner le num�ro de l'�tudiant "<<i+1<< ": ";
        cin>>T[i].num;
        cout<<"Donner le nom de l'�tudiant "<<i+1<< ": ";
        cin>>T[i].nom;
        cout<<"Donner la moyenne de l'�tudiant "<<i+1<< ": ";
        cin>>T[i].moy;
    }
    cout<< "Voici vos �tudiants :"<<endl;
    for(i=0;i<3;i++)
    cout<<"{"<<T[i].num<<","<<T[i].nom<<","<<T[i].moy<<"} ";
}
