#include <iomanip>       // pour les "manipulateurs param�triques"
#include <iostream>
using namespace std ;

main()

{ int i,j;
int t[3][4] = { { 1, 2, 3, 4 } ,{ 5, 6, 7, 8 },{ 9,1005,11,12 } } ;
// ou bien : int t[3][4] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 } ;

cout<<endl<<"1er affichage :"<<endl;
for (i=0 ; i<3 ; i++)
 {
  for (j=0 ; j<4 ; j++)
    cout<<t[i][j]<<" " ;
  cout<<endl;
 }

cout.setf (ios::fixed, ios::floatfield) ;
cout<<endl<<"2eme affichage :"<<endl ;

 for (i=0 ; i<3 ; i++)
 {
  for (j=0 ; j<4 ; j++)
    cout<<setw(4)<<t[i][j]<<" " ;
  cout<<endl;
 }
}


