#include<iostream>
using namespace std;
main()
{
    int i,j,n ;
    cout<< "donner le nombre de lignes : ";
    cin>>n;
    for (i=n;i>0;i--)
      {
       for (j=0;j<i;j++)
          cout<<"* ";
       cout<<endl;
      }
}
