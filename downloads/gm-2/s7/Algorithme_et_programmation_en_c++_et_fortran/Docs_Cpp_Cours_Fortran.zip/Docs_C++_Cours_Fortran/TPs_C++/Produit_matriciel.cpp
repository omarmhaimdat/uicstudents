#include<iostream>
#include <iomanip>
using namespace std;
#define n 3
#define m 3
#define p 2
 main()
{
int i,j,k ;
int A[n][m], B[m][p], C[n][p] ;
for (i=0 ;i<n ;i++)
  for (j=0 ;j<m ;j++)
   {cout<<"Donner A["<<i<<"]["<<j<<"]";
    cin>>A[i][j] ;
   }
/* Lecture de la matrice B */
for (i=0 ;i<m ;i++)
for (j=0 ;j<p ;j++)
  { cout<<"Donner B["<<i<<"]["<<j<<"]";
    cin>>B[i][j] ;
  }
/* Calcul du produit */
cout.setf (ios::fixed, ios::floatfield) ;
for (i=0 ;i<n ;i++)
  for (j=0 ;j<p ;j++)
    {C[i][j]=0 ;
     for (k=0 ;k<m ;k++) C[i][j]+=A[i][k]*B[k][j] ;
    }
/* Affichage de la matrice C */
for (i=0 ;i<n ;i++)
 {
  for (j=0 ;j<p ;j++) cout<<setw(5)<<C[i][j]<<" " ;
  cout<<endl;
 }
}
