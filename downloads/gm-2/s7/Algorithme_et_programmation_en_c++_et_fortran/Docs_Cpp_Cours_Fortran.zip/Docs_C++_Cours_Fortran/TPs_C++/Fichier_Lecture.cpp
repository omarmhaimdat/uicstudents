#include <cstdlib>   // pour exit
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std ;

const int LGMAX = 60;
main()
{
char nomfich [LGMAX+1] ;
int n ;
cout << "nom du fichier a lister : " ;
cin >> setw (LGMAX) >> nomfich ;

ifstream entree (nomfich, ios::in|ios::binary) ;

if (!entree)
 { cout << "ouverture impossible \n" ;
   exit (-1) ;
 }

while ( entree.read ( (char*)&n, sizeof(int) ) )
   cout << n << "\n" ;

entree.close () ;
}
