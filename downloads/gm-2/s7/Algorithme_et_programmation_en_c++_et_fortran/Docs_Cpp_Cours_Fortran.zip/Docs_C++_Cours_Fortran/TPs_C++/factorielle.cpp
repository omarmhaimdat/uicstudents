#include <iostream>

using namespace std;

int main ()
{
	int i, facto=1,n;
	cout<<"Donner la valeur de n : ";
	cin>>n;
	if (n==0)
        facto=1;
    else
	  for (i=2; i<=n; ++i)
        facto=facto*i;
cout<<"Factorielle de "<<n<<" = "<<facto<<endl;
}

