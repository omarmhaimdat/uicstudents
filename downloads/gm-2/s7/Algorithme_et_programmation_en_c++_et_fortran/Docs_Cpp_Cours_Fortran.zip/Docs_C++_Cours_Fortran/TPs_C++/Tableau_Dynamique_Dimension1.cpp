#include <iostream>
using namespace std;
main()
{
    int i,n;
    int *T;
    cout<<"Donner la taille du tableau:";
    cin>>n;
    T=new int[n];
    cout<<"Donner les elements du tableau:";
    for (i = 0; i < n; i++)
        cin>>T[i];
    cout<<"Voici les elements de votre tableau:"<<endl;
    for (i = 0; i < n; i++)
        cout<<T[i]<<" ";
    delete [] T;
    cout<<endl;
    cout<<"Le tableau T est libere";
}
