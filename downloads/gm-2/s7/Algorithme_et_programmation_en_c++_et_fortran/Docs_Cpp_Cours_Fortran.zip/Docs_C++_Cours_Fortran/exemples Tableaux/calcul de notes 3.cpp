#include <iostream>
#include <valarray>
using namespace std;
int main () {
    //déclarations et initialisation des variables
    float somme=0;
    int i;
    //déclaration d'un tableau note qui pourra stocker 6 données de type float
    valarray <float> note(6);
    //boucle de saisie des notes
    //la fonction size récupère la taille du tableau
    for(i=0; i<note.size();++i)
    {
        cout<<"Entrez la note N°"<<i+1<<" : ";
        cin>>note[i];
    }
    //boucle d'affichage des notes
    for(i=0;i<note.size();++i)
        cout<<"note n° "<<i<<" = "<<note[i]<<endl;
    //boucle de calcul du total
    for(i=0;i<note.size();++i)
        somme+=note[i];
    //affichage et calcul de la moyenne
    cout<<"La moyenne est : "<<somme/6<<endl;
    return 0;
}


