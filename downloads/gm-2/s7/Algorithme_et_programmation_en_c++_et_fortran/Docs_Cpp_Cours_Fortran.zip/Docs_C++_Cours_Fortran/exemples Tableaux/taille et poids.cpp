#include <iostream>
using namespace std;
int main () {
    //déclaration de la matrice
    float pt[3][2];
    //déclaration et initialisation des variables
    float poids=0, taille=0;
    int i, j;
    //boucles de saisie et d'affichage des poids et taille
    for (i=0; i<3; i++)
    {
        for(j=0; j<2; j++)
        {
            cout<<"Indices : ["<<i<<"]["<<j<<"]"<<endl;
            if (j==0) {
                cout<<"Poids : ";
                cin>>pt[i][j];
            }
            else 
            {
                cout<<"Taille : ";
                cin>>pt[i][j];
            }            
        }
    }
    //boucles de calcul des sommes des poids et des tailles
    for (i=0; i<3; i++)
        for(j=0; j<2; j++)
        {
            if (j==0) poids+=pt[i][j]; 
            else taille+=pt[i][j];
        }
    //affichage des moyennes des poids et tailles
    cout<<"Moyenne poids : "<<poids/3<<endl;
    cout<<"Moyenne âge : "<<taille/3<<endl;
	return 0;
}



