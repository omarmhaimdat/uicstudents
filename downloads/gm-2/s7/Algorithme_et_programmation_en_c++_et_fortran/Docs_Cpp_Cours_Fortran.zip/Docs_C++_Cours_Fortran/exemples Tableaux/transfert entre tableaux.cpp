#include <iostream>
#include <vector>
using namespace std;
int main () {  
    //déclarations de i et des deux tableaux de type flottant valeur1 et valeur2
    int i;
    vector<float> valeur1(10), valeur2(10);
    cout<<"Saisissez 10 nombres"<<endl;
    //boucle de saisie de 10 nombres rangés dans valeur1
    for(i=0; i<valeur1.size();++i)
        cin>>valeur1[i];
    cout<<"Contenu du tableau valeur1 :"<<endl;
    //boucle qui affiche le contenu de valeur1
    for(i=0; i<valeur1.size();++i)
        cout<<"A l'indice "<<i<<" on a : "<<valeur1[i]<<endl;
    //affectation de valeur1 à valeur2
    valeur2=valeur1;
    //boucle d'affichage du contenu de valeur2
    cout<<"Contenu du tableau valeur2 :"<<endl;
    for(i=0; i<valeur2.size();++i)
        cout<<"A l'indice "<<i<<" on a : "<<valeur2[i]<<endl;
    return 0;
}

