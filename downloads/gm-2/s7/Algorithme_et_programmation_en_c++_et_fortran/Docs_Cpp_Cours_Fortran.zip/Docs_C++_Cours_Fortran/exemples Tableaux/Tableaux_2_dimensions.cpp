#include <iomanip>       // pour les "manipulateurs param�triques"
#include <iostream>
using namespace std ;

main()

{ int i,j;
int t[3][4] = { { 1, 2, 3, 4 } ,{ 5, 6, 7, 8 },{ 9,10000,7,0 } } ;
// ou bien : int t[3][4] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 } ;

cout<<endl<<"1er affichage :"<<endl;
for (i=0 ; i<3 ; i++)
 {
  for (j=0 ; j<4 ; j++)
    cout<<t[i][j]<<" " ;
  cout<<endl;
 }

cout.setf (ios::fixed, ios::floatfield) ;
cout<<endl<<"2eme affichage :"<<endl ;

 for (i=0 ; i<3 ; i++)
 {
  for (j=0 ; j<4 ; j++)
    cout<<setw(5)<<t[i][j]<<" " ;
  cout<<endl;
 }
 cout << setbase(16) << 256 << endl; // affiche 100 et passe `a la ligne
cout << setprecision(5) << setfill('*') << setw(10) << 123.45678; // affiche ****123.46
}


