#include <iostream>
using namespace std;
int main () {
    //déclaration et initialisation du tableau carre
    int carre[2][3]={{1,2,3},{1,4,9}};
    //boucles d'affichage du contenu du tableau
    for (int ligne=0; ligne<2; ligne++)
    {
        for(int colonne=0; colonne<3; colonne++)
			cout<<carre[ligne][colonne]<<endl;
    }
    return 0;
}




