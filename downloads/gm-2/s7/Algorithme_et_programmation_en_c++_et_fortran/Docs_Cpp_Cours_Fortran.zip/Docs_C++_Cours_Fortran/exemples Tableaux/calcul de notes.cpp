#include <iostream>
using namespace std;
int main () {
    //déclarations et initialisation du vecteur et des variables
    float note[6];
    float somme=0;
    int i;
    //boucle de saisie des notes
    for (i=0; i<6; ++i)
    {
        cout<<"Entrez la note n°"<<i+1<<" : ";
        cin>>note[i];
    }
    //boucle de lecture du vecteur et de calcul du total
    for (i=0; i<6; ++i)
        somme=somme+note[i];
    //affichage et calcul de la moyenne
    cout<<"Moyenne = "<<somme/6<<endl;
    return 0;
}


