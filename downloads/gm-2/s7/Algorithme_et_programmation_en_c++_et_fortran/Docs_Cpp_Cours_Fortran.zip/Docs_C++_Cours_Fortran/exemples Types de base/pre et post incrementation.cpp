#include <iostream>
using namespace std;
int main(){
    //déclaration et initialisation des variables x et y
    int x=1, y=1;
    //affichage de x, pré-icrémenté
    //x est incrémenté, puis placé dans le flux de sortie
    cout << "++x = " << ++x << endl;
    cout << "x   = " << x << endl;
    cout << endl;
    //affichage de y, post-incrémenté
    //y est placé dans le flux de sortie, puis incrémenté
    cout << "y++ = " << y++ << endl;
    cout << "y   = " << y << endl;    
    return 0;
}
