
#include <iostream>
using namespace std;
int main () {
	//déclaration et initialisation des variables
	int a=100, b=7, c=100, DIV=-69, div=10, x=1;

	//quelques opérations arithmétiques

	//100+7=1007
	cout<<"a+b="<<a+b<<endl;
	//100-7=93
	cout<<"a-b="<<a-b<<endl;
	//100x7=700
	cout<<"a*b="<<a*b<<endl;
	//-7
	cout<<"-b="<<-b<<endl;
	//division entière

	//-69/10=-6
	cout<<"DIV/div="<<DIV/div<<endl;
	//Reste de 69/10=-9
	cout<<"modulo(DIV/div)="<<DIV%div<<endl;

	//décrémentation, incrémentation pré ou post
	//a pré-incrémenté : il est incrémenté
	cout<<"++a="<<++a<<endl;
	//puis placé dans le flux de sortie
	cout<<"a="<<a<<endl;
	//b est post-incrémenté : il reste avec sa valeur initiale
	cout<<"b++="<<b++<<endl;
	//puis est incrémenté et placé dans le flux de sortie
	cout<<"b="<<b<<endl;
	//maintenant a=101 et b=8

	//opérateur conditionnel
	//en fonction de la condition, on a 1 ou 0
	//avec a=101 et b=8
	//a est n'est pas inférieur à b alors 0
	cout<<"a<b -> "<<((a<b)?1:0)<<endl;
	//a est supérieur à b alors 1
	cout<<"a>b -> "<<((a>b)?1:0)<<endl;
	//a n'est pas égal à b alors 0
	cout<<"a==b -> "<<((a==b)?1:0)<<endl;
	//a est différent de b alors 1
	cout<<"a!=b -> "<<((a!=b)?1:0)<<endl;

	//opérateurs logiques
	//avec a=101 et b=8
	//si a < b et b < c alors vrai sinon faux
	cout<<((a<b)&&(b<c)?"vrai":"faux")<<endl;
	//si a < b et a > c alors vrai sinon faux
	cout<<((a<b)||(a>c)?"vrai":"faux")<<endl;
	//si a < b et b >= 100 alors x=x-a-1 sinon x=x-c/-b soit x=1-(101/-8) => x=1-(-12) => x=13
	x-=((a<b)&&(b>=100)?--a:c/-b);
	cout<<"x="<<x<<endl;

    return 0;
}
