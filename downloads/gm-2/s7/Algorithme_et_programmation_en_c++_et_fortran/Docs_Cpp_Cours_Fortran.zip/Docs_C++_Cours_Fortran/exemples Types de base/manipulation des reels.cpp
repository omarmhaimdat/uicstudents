#include <iostream>

using namespace std;

int main () {
	for(int i=8; i<=65536; i=i+256)
	{
		float flt_std=1.0/i;
		double flt_double=1.0/i;
		long double flt_long=1.0/i;
		cout<<"float : "<<flt_std<<endl;
		cout<<"double : "<<flt_double<<endl;
		cout<<"long double : "<<flt_long<<endl;
		cout<<"----------"<<endl;
	}
	return 0;
}
