#include <iostream>
using namespace std;
int main () {
    //déclarations des variables
    int x=10.125;
    float y=10.125;
    int z=2;
    //affichage de la variable x qui est convertie implicitementt en nombre entier
    cout<<"x = "<<x<<endl;
    x=x+0.5;
    //attention, ce n'est pas un arrondi, seule la partie entière est conservée
    cout<<"x + 0.5 = "<<x<<endl;
    //affichage de la variable y, nombre réel
    cout<<"y = "<<y<<endl;
    //affichage de la variable z, nombre entier
    cout<<"z = "<<z<<endl;
    //affichage du calcul y + z, le résultat est un nombre réel par conversion implicite
    cout<<"y + z = "<<y+z<<endl;
    return 0;
}
