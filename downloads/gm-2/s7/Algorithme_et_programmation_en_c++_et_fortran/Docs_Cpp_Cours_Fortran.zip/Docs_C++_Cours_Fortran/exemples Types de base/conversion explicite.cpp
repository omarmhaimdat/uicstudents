#include <iostream>

using namespace std;

int main () {
	//déclaration des variables
	int x;
	char y;
	float z;
	//conversion explicite
	x=(int)('A');  
	y='A';
	//affichage de x et y
	cout<<"x = "<<x<<endl;
	cout<<"y = "<<y<<endl;
	//conversion explicite et affichage
	z=(int) 2.718;
	cout<<"z = "<<z<<endl;
	//conversion explicite et affichage	
	z=int(2.718);
	cout<<"z = "<<z<<endl;
    return 0;
}
