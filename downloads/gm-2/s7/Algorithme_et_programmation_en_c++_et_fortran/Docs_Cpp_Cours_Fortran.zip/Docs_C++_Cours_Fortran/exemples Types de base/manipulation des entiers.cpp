#include <iostream>
using namespace std;
int main ()
{
	//initialisation des variables
	char char_std=65;
	unsigned char char_uns=65;
	short int int_short=1;
	int int_std=1;
	long int int_long=1;
	unsigned short int int_short_uns=1;
	unsigned int int_std_uns=1;
	unsigned long int int_long_uns=1;
	//affichage des variables après initialisation
	cout<<char_std<<"  "<<char_uns<<"  "<<endl;
	cout<<int_short<<"  "<<int_std<< "  " <<int_long<< "  ";
	cout<<int_short_uns<<"  "<< int_std_uns<<"  "<<int_long_uns << endl;
	//affichage de la taille en octets prise par chaque variable
	cout<<sizeof(int_short)<<"  "<<sizeof(int_std)<<"  "<<sizeof(int_long)<<"  ";
	cout<<sizeof(int_short_uns)<<"  "<<sizeof(int_std_uns)<<"  "<<sizeof(int_long_uns)<<endl;
	cout << endl;
	//boucle de 1 à 32 affichant la valeur de chaque variable suivant une suite croissante des puissances de 2
	for (int i=1; i<=32; ++i)
	{
		int_short=int_short*2;
		int_std=int_std*2;
		int_long=int_long*2;
		int_short_uns=int_short_uns*2;
		int_std_uns=int_std_uns*2;
		int_long_uns=int_long_uns*2;
		//affichage de l'indice de la boucle
		cout<<"ind : "<<i<<endl;
		//affichage des valeurs calculées pour chaque variable
		cout<<"short int : "<<int_short<<endl;
		cout<<"int : "<<int_std<<endl;
		cout<<"long int : "<<int_long<<endl;
		cout<<"unsigned short int : "<<int_short_uns<<endl;
		cout<<"unsigned int : "<<int_std_uns<<endl;
		cout<<"unsigned long int : "<<int_long_uns<<endl;
		cout<<endl;
	}
	return(0);
}
