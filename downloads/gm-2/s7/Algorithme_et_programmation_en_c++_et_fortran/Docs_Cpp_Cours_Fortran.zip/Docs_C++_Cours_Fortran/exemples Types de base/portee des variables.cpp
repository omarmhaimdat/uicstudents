#include <iostream>
using namespace std;
//déclarations et initialisations des variables globales e et i
double e=2.718 ;
int i=1;
//programme principal
int main(){
    //déclarations et initialisations des variables locales j et e
    int j=2;
    double e=1.282 ;
    //somme e:globale + e:locale
    e=::e+e;
    //affichage des résultats
    cout<<"La somme e = "<<e<<endl;
    cout<<"La variable locale j = "<<j<<endl;
    cout<<"La variable globale i = "<<i<<endl;
    cout<<"la variable globale e = "<<::e<<endl;
    cout<<"La somme i + e (avec i:globale et e:locale) est égale à : "<<i+e<<endl;
}
