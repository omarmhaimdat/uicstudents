#include <iostream>
using namespace std;
int main () {
    //déclarations des constantes
	const float e=2.718;
    const double PI=3.14159265;
    const char beep='\b';
    const float e2=e*2;
    //affichage des constantes
    cout<<"e = "<<e<<endl;
    cout<<"PI = "<<PI<<endl;
    cout<<"Beep!"<<beep<<endl;
    cout<<"2 * e = "<<e2<<endl;
    //opération de cast explicite sur la constante e
    cout<<"int(e) = "<<int(e)<<endl;
    return 0;
}

