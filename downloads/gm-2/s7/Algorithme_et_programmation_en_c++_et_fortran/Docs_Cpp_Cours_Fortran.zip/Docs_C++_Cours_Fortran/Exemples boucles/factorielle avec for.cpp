#include <iostream>

using namespace std;

int main () {
	//déclaration et intialisation des variables
	int i, facto=1, puiss=2;
	//boucle for de 2 à 12 suivant un pas i égal à 1
	for (i=2; i<=12; ++i)
	{
		//calcul de la fcatorielle
		facto=facto*i;
		//affichage des factorielles
		cout<<"Factorielle de "<<i<<" = "<<facto<<endl;
	}
	//boule de 2 à 16 suivant un pas j égal à 1 et déclaré entier
	for (int j=2; j<=16; ++j)
	{
		//calcul de la somme
		puiss=puiss*2;
		//affichage des puissances de 2
		cout<<"2 à la puissance "<<j<<" = "<<puiss<<endl;
	}		
    return 0;
}
