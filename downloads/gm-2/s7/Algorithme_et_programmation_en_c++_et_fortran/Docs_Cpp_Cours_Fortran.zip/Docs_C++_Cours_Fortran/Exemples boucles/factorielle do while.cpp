#include <iostream>

using namespace std;

int main () {
	//déclaration des variables
	int i, j, f=1;
	//saisie de i, nombre dont on va calculer la factorielle
	cout<<"Entrez le nombre entier dont vous voulez la factorielle : ";
	cin>>i;
	//affectation de i à j pour l'affichage du résultat
	j=i;
	//boucle do...while
	do
	{
		//calcul de la factorille
		f*=i;
		//décrémentation de i
		--i;
	}
	//test si i=0 pour savoir si le calcul doit se terminer
	while (i!=0);
	//affichage du résultat suivant j
	cout<<"Factorielle de "<<j<<" = "<<f<<endl;	
    return 0;
}
