#include <iostream>

using namespace std;

int main () {
	//déclaration des variables
	char prenom, nom;
	int entier1, entier2, entier3;
	//affichage de la chaîne "Entrez vos 2 initiels"
	cout<<"Entrez vos 2 intiales : "<<endl;
	//attente de l'entrée des 2 initiales
	cin>>prenom>>nom;
	//affichage de de la chaîne "Initiales : " suivi des 2 intiales espacées de 2 tabulations et suivi d'une fin de ligne
	cout<<"Initiales : "<<nom<<"\t\t"<<prenom<<"\n";
	//affichage de la chaîne "Entrez 3 nombres entiers :"
	cout<<"Entrez 3 nombres entiers"<<endl;
	//attente de l'entrée de 3 nombres entiers
	cin>>entier1>>entier2>>entier3;
	//afficahge des 3 nombres saisis séparés par une tabulation et suivi d'une fin de ligne
	cout<<"Les nombres étaient : "<<entier1<<"\t"<<entier2<<"\t"<<entier3<<"\n";
    return 0;
}
