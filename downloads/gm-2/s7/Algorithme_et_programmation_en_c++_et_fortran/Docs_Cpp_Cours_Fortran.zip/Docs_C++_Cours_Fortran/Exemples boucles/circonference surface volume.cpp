#include <iostream>

using namespace std;

int main () {
	//déclaration des variables
	float rayon;
	char calcul;
	//saisie du Rayon
	cout<<"Rayon : ";
	cin>>rayon;
	//saisie du calcul : C, S ou V
	cout<<"Calcul C, S ou V : ";
	cin>>calcul;
	//sélection d'un choix en fct de calcul
	switch (calcul){
		case 'C':
			//affichage et calcul de la circonférence
			cout<<"Circonférence du cercle = "<<2*3.14*rayon<<endl;
			//arrêt du traitement
			break;
		case 'S':
			//affichage et calcul de la surface
			cout<<"Surface du cercle = "<<3.14*rayon*rayon<<endl;
			//arrêt du traitement
			break;
		case 'V':
			//affichage et calcul du volume
			cout<<"Volume de la sphère : "<<4/3*3.14*rayon*rayon<<endl;
			//arrêt du traitement
			break;
		default:
			//affichage message alerte en cas de choix inexistant
			cout<<"Calcul inexistant, seul C, S et V sont autorisés"<<endl;
			//arrêt du traitement
			break;
			//fin de la sélection
			}
    return 0;
}
