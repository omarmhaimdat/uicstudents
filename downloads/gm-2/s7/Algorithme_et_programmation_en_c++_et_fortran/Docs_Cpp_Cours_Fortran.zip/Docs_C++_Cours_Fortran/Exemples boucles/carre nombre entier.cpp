#include <iostream>

using namespace std;

int main () {
	//déclaration de la variable n
    int n;
	//saisie d'un premier nombr entier
	cout<<"Saisissez un nombre entiers positif : ";
	cin>>n;
	//boucle tant que n est différent de 0
	while(n!=0)
	{
		//affichage du carré de n
		cout<<"Le carré de "<<n<<" est égal à : "<<n*n<<endl;
		//saisie du nombre suivant
		cout<<"Nombre suivant (0 pour terminer) :"; 
		cin>>n;
	}
	return 0;
}
