#include <iostream>

using namespace std;

int main () {
	//déclaration et initilisation des variables
	int i, j[]={0,1,2,3,4,5,6,7,8,9};
	//création d'une boucle de 0 à 10
	for (i=0;i<10;++i)
	{
		//si j[i] est supérier à 7 alors aller à l'étiquette end
		if (j[i]>7) goto end;
		//affichage de i et j
		cout<<"Quand i vaut "<<i<<" j est égal à "<<j[i]<<endl;
		//continue si j[i] est inférieur à 7 avec reprise à l'itération suivante sans exécuter la suite du bloc d'instructions
		continue;
		//étiquette end, affichage de l'arrêt de la boucle, j[i] est supérieur à 7
		end:cout<<"j[i] = "<<j[i]<<", c'est supérieur à 7, donc la boucle s'arrête"<<endl;
		//arrêt de la boucle
		break;
	}
    return 0;
}
