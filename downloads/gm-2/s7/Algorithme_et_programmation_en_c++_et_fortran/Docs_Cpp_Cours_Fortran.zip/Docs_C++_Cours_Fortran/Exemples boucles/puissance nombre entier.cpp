#include <iostream>

using namespace std;

int main () {
	//déclaration et initialisation des variables
	int n, exp, puiss=1;
	//boucle while tant que vrai
	while(1)
	{
		//saisie d'un nombre entier n
		cout<<"Saisissez un nombre entier ou 0 pour terminer : ";
		cin>>n;
		//test du nombre entier saisi, si il est égal à 0 alors arrêt
		if (n==0) break;
		//saisie de l'exposant exp
		cout<<"Saisissez l'exposant : ";
		cin>>exp;
		//boucle pour mettre le nombre entier n saisi à la puissance exp
		for (int i=1;i<=exp;++i)
			//calcul de la variable puiss
			puiss*=n;
		//affichage du résultat
		cout<<n<<" exposant "<<exp<<" = "<<puiss<<endl;
		//réinitialisation de la variable puiss pour le calcul suivant
		puiss=1;
	}
    return 0;
}
