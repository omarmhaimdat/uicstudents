#include <iostream>

using namespace std;

int main () {
	//déclaration des variables
	int i, j, k;
	//2 boucles i avec un pas de 1 et j avec un pas de 5 jusqu'à ce que i soit égal à 10
	for(i=0, j=0; i<=10; ++i, j+=5)
		//affichage de i et j
		cout<<"i = "<<i<<" et j = "<<j<<endl;
	//boucle qui se décrémente suivant un pas égal à -50
	for(k=100; k>=-50; k-=25)
		//affichage de k
		cout<<"k = "<<k<<endl;
    return 0;
}
