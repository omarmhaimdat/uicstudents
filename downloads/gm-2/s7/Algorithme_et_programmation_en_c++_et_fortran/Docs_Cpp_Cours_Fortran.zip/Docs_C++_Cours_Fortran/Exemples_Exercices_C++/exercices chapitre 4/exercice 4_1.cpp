#include <iostream>
using namespace std;
int main () {
    //déclaration et initialisation des variables
    long nb, r, n=0;
    //saisie d'un nombre entier positif
    cout<<"Saisissez un nombre entier positif : ";
    cin>>nb;
    //boucle d'inversion
    while (nb>0)
    {
        r=nb%10;
        nb/=10;
        n=10*n+r;
    }
    //affichage du nombre inversé
    cout<<"Après inversion de ses chiffres, le nombre devient : "<<n<<endl;
    return 0;
}
