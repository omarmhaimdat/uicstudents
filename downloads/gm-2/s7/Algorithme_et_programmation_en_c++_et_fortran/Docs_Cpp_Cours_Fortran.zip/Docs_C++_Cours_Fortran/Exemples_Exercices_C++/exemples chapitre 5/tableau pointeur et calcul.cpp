#include <iostream>

using namespace std;

int main () {
	//déclaration et initialisation d'un tableau d'entiers
	int tableau[7]={5, 525, 32, 125, -45, 12, 0};
	//déclaration et intialisation de la variable i, index du tableau, et de la variable somme
	int i=0, somme=0;
	//boucle de lecture des contenus et de leurs adresses
	for(int *adr=tableau; adr<tableau+7; ++adr)
	{
		cout<<"tableau["<<i<<"] = "<<*adr<<" à l'adresse : "<<adr<<endl;
		//incrément de i
		++i;
		//calcul de la somme intermédiaire
		somme+=*adr;
	}
	//affichage de la somme totale des éléments du tableau
	cout<<"La somme des éléments du tableau est égale à : "<<somme<<endl;
    return 0;
}
