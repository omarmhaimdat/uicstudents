#include <iostream>
using namespace std; 
int main()
{	
	//déclaration des variables
	int tabint[20], n, x;    
	int *p1, *p2; 
	
	//saisie de n, x et du contenu de tabint
	cout<<"Saisissez la taille du tableau (maxi 20) : ";
	cin>>n;
	for (p1=tabint; p1<tabint+n; ++p1)
	{
		cout<<"Elément n°"<<p1-tabint<<" : ";
		cin>>*p1;
	}
	cout<<"Saisissez la valeur à supprimer : ";
	cin>>x;
	//affichage du tableau de départ
	cout<<"Le tableau que vous avez saisi : "<<endl;
	for (p1=tabint; p1<tabint+n; ++p1) cout<<*p1<<endl;
	// supprimer x et compreser le tableau
	for (p1=p2=tabint; p1<tabint+n; ++p1)
	{
		*p2 = *p1;
		if (*p2!=x) ++p2;
	}
	//affectation à n de la nouvelle dimension de tabint
	n = p2-tabint;
	//affichage du tableau compressé
	cout<<"Le tableau résultat : "<<endl;
	for (p1=tabint; p1<tabint+n; ++p1) cout<<*p1<<endl;
	return 0;
}
