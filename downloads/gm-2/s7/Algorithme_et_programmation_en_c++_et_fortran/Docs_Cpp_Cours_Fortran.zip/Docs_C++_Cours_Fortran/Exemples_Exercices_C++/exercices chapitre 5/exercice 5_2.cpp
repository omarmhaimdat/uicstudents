#include <iostream>
using namespace std; 
int main()
{
	//déclarations des variables et pointeurs
	char palin[50], *p1, *p2;
	int flag; 		
	//saisie des données
	cout<<"Saisissez un mot (maxi 50 caractères) : ";
	gets(palin);
	//positionner p2 en fin de chaîne
	for (p2=palin; *p2; ++p2);
	--p2;
	//passe flag1 à 1 ce qui impliquera que palin est un palindrome
	flag=1;
	for (p1=palin ; flag && p1<p2 ; ++p1, --p2)
		if (*p1!=*p2) flag=0;
	//test de flag1 et affichage du résultat
	if (flag) cout<<"Le mot "<<palin<<" est un palindrome"<<endl;
	else
		cout<<"Le mot "<<palin<<" n'est pas un palindrome "<<endl;	
	return 0;
}