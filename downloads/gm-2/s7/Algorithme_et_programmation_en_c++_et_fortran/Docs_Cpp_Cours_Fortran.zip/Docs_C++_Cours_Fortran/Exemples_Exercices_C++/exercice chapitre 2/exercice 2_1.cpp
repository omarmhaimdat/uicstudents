#include <iostream>
using namespace std;
//déclaration des types énumérations
enum choix{pierre, papier, ciseaux};
enum score{joueur1, joueur2, egalite};

int main () {
	//déclaration d'une variable n
    int n;
	//déclarations de 2 variables c1 et c2 de type choix
	choix c1, c2;
	//déclaration d'une variable s de type score
	score s;
	//affichage des consignes et saisie des scores
	cout<<"Votre choix (pierre:0 - papier:1 - ciseaux:3) : "<<endl;
	cout<<"Joueur N°1 : ";
	cin>>n;
	//affectation du choix à c1
	c1=choix(n);
	cout<<"Joueur N°2 : ";
	cin>>n;
	//affectation du choix à c2
	c2=choix(n);
	//tests pour déterminer quel est le joueur gagnant
	if(c1==c2) s=egalite;
	else if(c1==pierre)
		if(c2==papier) s=joueur2;
		else s=joueur1;
	else if (c1==papier)
		if (c2==pierre) s=joueur1;
			else s=joueur2;
	else if(c1==ciseaux)
		if (c2==pierre) s=joueur2;
			else s=joueur1;
	//test la variable s pour afficher le résultat
	if (s==egalite) cout<<"Egalité"<<endl;
			else if (s==joueur1) cout<<"Le joueur N°1 a gagné"<<endl;
				else cout<<"Le joueur N°2 a gagné"<<endl;
    return 0;
}
