#include <iostream>
using namespace std;
//prototype de la fonction fibonacci
int fibonacci(int n);
int main()
{
	//déclaration de n
	int n;
	//saisie de n
	cout<<"Saisissez un nombre entier inférieur à 30 : ";
	cin>>n;
	//test si n est inférieur ou égal à 30 sinon affiche un avertissement
	if (n<=30) 
		//affichage du réultat via l'appel de la fonction fibonacci
		cout << "F("<< n <<") = " << fibonacci(int(n)) << endl;		
	else
		cout<<"Le nombre saisi doit être inférieur ou égal à 30"<<endl;
	return 0;
}
//fonction fibonacci
int fibonacci(int n)
{
	//test si n est égal à 0, dans ce cas renvoie 0
	if (n == 0)
		return 0;
	//sinon test si n est égal à 1, dans ce cas renvoie 1
	else if (n == 1)
		return 1;
	//sinon renvoie le résultat via un appel récursif de la fonction fibonacci sur n-1 + n-2
	else
		return fibonacci(n-1) + fibonacci(n-2);
}

