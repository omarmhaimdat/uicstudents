#include <iostream>
#include <string>

using namespace std;
int main () {
    //déclaration des variables texte1, texte2 et texte3
    char texte1[]="Il était un";
    char texte2[]=" petit navire";
    char texte3[25];
    //affichage des résultats et utilisation des fonctions
    cout<<"texte1 + texte2 : "<<strcat(texte1,texte2)<<endl;
    cout<<"texte3 : "<<strcpy(texte3,texte1)<<endl;
    cout<<"Taille de la chaine texte1 : "<<strlen(texte1)<<endl;
    cout<<"Quel texte commence à partir de la lettre 'v' : "<<strchr(texte1,'v')<<endl;
    return 0;
}


