#include <iostream>
#include <valarray>
using namespace std;
int main(void)
{
    //déclaration et initialisation d'un tableau tab1
    int tab1[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    //déclaration d'un valarray tab2
    valarray <int> tab2(tab1, 10);
    //déclaration d'un valarray tab3
    valarray <int> tab3(10);
    //affiche les entiers contenus dans tab2 séparés par une tabulation
    for (int i=0; i<tab2.size(); ++i) cout << tab2[i] << "\t";
    //passe à la ligne suivante
    cout<<endl;
    //décale tab2 à gauche de deux positions
    tab3 = tab2.shift(2);
    //affiche les entiers contenus dans tab3 séparés par une tabulation
    for (int i=0; i<tab2.size(); ++i) cout << tab3[i] << "\t";
    //passe à la ligne suivante
    cout<<endl;
    // effectue une rotation de tab2 de 2 positions vers la droite
    tab3 = tab2.cshift(-2);
    //affiche les entiers contenus dans tab3 séparés par une tabulation
    for (int i=0; i<tab2.size(); ++i) cout << tab3[i] << "\t";
    return 0;
}





