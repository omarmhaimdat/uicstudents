#include <iostream>
using namespace std;
int main () {
    //déclaration et initialisation du tableau de caractère tab et déclaration d'une variable caractère temp
    char tab[8]={'A', 'Z', 'C', 'N', 'P', 'F', 'G', 'S'}, temp;
    //boucle de lecture et d'inversion via la variable temporaire temp
    for (int i=0; i<4; ++i)
    {
        temp=tab[i];
        tab[i]=tab[7-i];
        tab[7-i]=temp;
    }
    //boucle d'affichage des valeurs séparées par une tabulation
    for (int j=0; j<8; ++j) cout<<tab[j]<<"\t";
    return 0;
}




