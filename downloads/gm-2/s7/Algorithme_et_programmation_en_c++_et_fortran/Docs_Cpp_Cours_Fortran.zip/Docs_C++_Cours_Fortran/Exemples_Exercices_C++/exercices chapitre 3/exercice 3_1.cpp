#include <iostream>
using namespace std;
int main () {
    //déclaration et intialisation des variables
    //l est le n° de la ligne
    //c est le n° de la colonne
    //nbzero contiendra le nombre de 0
    int l=6, c=3, nbzero=0;
    //déclaration et initiatisation du tableau bi-dimensionnel tab
    float 
	tab[6][3]={{12,0,10.5},{13,7.5,0},{14,6,8},{17,0,10},{15,13,12.5},{0,19,6}};
    //boucles de lecture des valeurs de tab
    for (int i=0; i<l;++i)
        for(int j=0; j<c; ++j)
            //test si la valeur lue est égale à 0 et dans ce cas incrémente nbzer
            if (tab[i][j]==0) ++nbzero;
    //affichage du résultat
    cout<<"Le nombre de valeur égale à 0 est : "<<nbzero<<endl;
    return 0;
}



