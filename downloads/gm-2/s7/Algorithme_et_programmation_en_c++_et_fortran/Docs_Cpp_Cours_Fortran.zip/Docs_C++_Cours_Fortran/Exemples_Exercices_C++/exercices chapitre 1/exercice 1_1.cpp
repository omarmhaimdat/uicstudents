#include <iostream> 
using namespace std; 
int main () {
	//déclarations et affectations
	char c=0; 
	unsigned char c_uns=0; 
	for (int i=33; i<127; ++i) 
	{
		cout<<i<<" = "; 
		c=i; 
		c_uns=i; 
		//affichage du caractère signé et non-signé 
		cout<<c<<" "<<c_uns<<endl;
		cout<<"— — — — — "<<endl; 
	}
	return 0;
}

