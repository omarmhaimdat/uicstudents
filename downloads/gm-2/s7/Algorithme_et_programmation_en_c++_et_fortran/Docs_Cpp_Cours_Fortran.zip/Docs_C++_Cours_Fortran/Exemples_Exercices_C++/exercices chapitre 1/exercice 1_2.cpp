#include <iostream>
using namespace std;
int main () {
    //déclarations des variables
    double x=10000;
    double y=x/9-1111;
    //affichage des résultats
    cout<<"y = "<<y<<endl;
    cout<<"y * 9 = "<<y*9<<endl;
    return 0;
}


