#include <iostream>
using namespace std;
//déclaration de la structure film
struct film{
	char titre[40];
	int annee;
}cine1, *cine2;

int main()
{
	//déclaration d'un tableau buffer de 40 caractères
	int an;
	//affectation de l'adresse de cine1 au pointeur cine2
	cine2=&cine1;
	//message de saisie du titre
	cout<<"Titre du film : ";
	//lit le titre saisie et le range dans la variable titre de la structure film
	cin.getline(cine2->titre,40);
	//message de saisie de l'année
	cout<<"Annee : ";
	//lit l'année et la range dans la variable buffer
	cin>>an;
	//accède et affecte le contenu de la variable an à la variable annee de la structure film via le pointeur cine2
	cine2->annee=an;
	//affiche le titre et l'année
	cout<<cine2->titre<<" - Annee : "<<cine2->annee<<endl;
	return 0;
}
