#include <iostream>
using namespace std;
//prototypes fonctions
void saisie(int);
void affichage(int);
//déclaration de la structure
struct personnel{
	char nom[25];
	char prenom[25];
	char sexe[1];
	int age;
}salarie[100];

int main () {
	int i, n;
	//saisie du nombre n de salariés à traiter
	cout<<"Nb de salariés à saisir : ";
	cin>>n;
	//appel de la fonction saisie n fois
	for(i=0; i<n; ++i)
	    saisie(i);
	//appel de la fonction affichage n fois
	for(i=0; i<n; ++i)
	  affichage(i);
	return 0;
}
//fonction saisie
void saisie(int i){
	cout<<"Nom : ";
	cin>>salarie[i].nom;
	cout<<"Prénom : ";
	cin>>salarie[i].prenom;
	cout<<"Sexe (M/F) : ";
	cin>>salarie[i].sexe;
	cout<<"Age : ";
	cin>>salarie[i].age;
}
//fonction affichage
void affichage(int i){
	cout<<salarie[i].nom<<" - "<<salarie[i].prenom<<" - "<<salarie[i].sexe<<" - "
	<<salarie[i].age<<" ans"<<endl;
}



