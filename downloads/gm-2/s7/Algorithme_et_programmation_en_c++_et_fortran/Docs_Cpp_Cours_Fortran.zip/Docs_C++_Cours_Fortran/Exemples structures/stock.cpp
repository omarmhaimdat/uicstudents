#include <iostream>
using namespace std;
//déclaration de la structure article
//veste1 et veste2 sont les variables "structurées"
struct article{
	int ref, qte;
	float taille;
	float prix;
}veste1, veste2;

int main () {
	//affectations
	veste1.ref=111;
    veste1.qte=3;
	veste1.taille=50;
	veste1.prix=98.5;
	veste2.ref=122;
    veste2.qte=2;
	veste2.taille=52;
	veste2.prix=98.5;
	//affichage
	cout<<"Ref : "<<veste1.ref<<" / Qté : "<<veste1.qte<<" / Taille : "<<veste1.taille<<" / Prix : "<<veste1.prix<<" DHs"<<endl;
	cout<<"Ref : "<<veste2.ref<<" / Qté : "<<veste2.qte<<" / Taille : "<<veste2.taille<<" / Prix : "<<veste2.prix<<" DHs"<<endl;
    return 0;
}
