#include <iostream>
using namespace std;
//prototypes des fonctions
void saisie(int);
void lecture(int);

//déclaration de la structure film
struct film{
	char titre[40];
	int annee;
};

//déclaration de la structure cinefil
struct cinefil{
	char nom[30];
	char prenom[30];
    film filmpref;
}membreclub[100];

int main()
{
	//Saisie du nombres de membres à traiter
	int i, nbm;
	cout<<"Nombre de membres a traiter : ";
	cin>>nbm;
	//boucle de saisie
	for (i=0; i<nbm;++i)
		saisie(i);
	//boucle de lecture et d'affichage
	for (i=0; i<nbm;++i)
		lecture(i);
	return 0;
}
//fonction saisie
void saisie(int i)
{
	cout<<"Nom : ";
	cin>>membreclub[i].nom;
	cout<<"Prenom : ";
	cin>>membreclub[i].prenom;
	cout<<"Film prefere : ";
	cin>>membreclub[i].filmpref.titre;
	cout<<"Annee : ";
	cin>>membreclub[i].filmpref.annee;
}
//fonction lecture
void lecture(int i)
{
	cout << membreclub[i].nom << " " << membreclub[i].prenom << " - film préferé : " << membreclub[i].filmpref.titre << " - "<< membreclub[i].filmpref.annee <<endl;
}
