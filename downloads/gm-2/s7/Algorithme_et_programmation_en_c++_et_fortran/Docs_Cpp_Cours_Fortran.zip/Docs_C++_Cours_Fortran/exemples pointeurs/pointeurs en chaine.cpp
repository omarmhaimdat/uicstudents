#include <iostream>

using namespace std; 

int main () {
	//déclaration et affectation de la valeur 99 à la variable x
	int x=99;
	//affichage de x
	cout<<"x = "<<x<<endl;
	//affectation de l'adresse de x au pointeur
	int *px=&x;
	//affichage de la valeur contenue dans le pointeur 
	cout<<"Pointeur sur x = "<<*px<<endl;
	//affichage de l'adresse de x
	cout<<"Adresse de x = "<<&x<<endl;
	//affectation de l'adresse du pointeur au pointeur de pointeur
	int **ppx=&px;
	//affichage de la valeur contenue dans le pointeur de pointeur
	cout<<"Pointeur de pointeur sur x = "<<**ppx<<endl;
	//affichage de l'adresse du pointeur
	cout<<"Adresse du pointeur sur x = "<<&px<<endl;
	//affectation de la valeur 100 au pointeur de pointeur
	**ppx=100;
	//affichage de x
	cout<<"x = "<<x<<endl;
    return 0;
}
