#include <iostream>

using namespace std;

int main () {
	//déclaration et initialisation des variables
	int i, j, maxi, mini, tableau[6];
	//boucle de saisie et de remplissage (6 nombres dans tableau)
	for (i=0; i<=5;++i)
	{
		cout<<"Saisissez un nombre entier : ";
		cin>>tableau[i];
	}
	//boucle de lecture des valeurs maxi et mini stockées dans le tableau
	//la lecture se fait via le pointeur *(tableau+j)
	maxi=mini=*tableau;
	for(j=1;j<=5;++j)
	{
		if (*(tableau+j)>maxi) maxi=*(tableau+j);
		if (*(tableau+j)<mini) mini=*(tableau+j);
	}
	//affichage des valeurs maxi et mini
	cout<<"Valeur maximum : "<<maxi<<endl;
	cout<<"Valeur minimum : "<<mini<<endl;
    return 0;
}
