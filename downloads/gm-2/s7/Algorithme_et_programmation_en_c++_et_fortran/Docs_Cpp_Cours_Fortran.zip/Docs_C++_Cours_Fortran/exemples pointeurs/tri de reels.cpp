#include <iostream>

using namespace std;

int main () {
	//déclaration des variables entieres
	int i, j, nb;
	//declarations des pointeurs
	float *tab[25], *temp;
	//declaration des reels
	float valeur;
	//saisie du nombre de valeurs à trier
	cout<<"Nombre de valeurs a trier (maxi : 25) : ";
	cin>>nb;
	//boucle de saisie des nombres
	for(i=0;i<nb;++i)
	{
		cout<<"Saisissez un nombre : ";
		cin>>valeur;
		//allocation memoire explicite du nombre dans le tableau
		tab[i]=new float(valeur);
	}
	//boucles de tri
	for(i=0;i<nb-1;++i)
		for (j=i+1;j<nb;++j)
			//test d'inversion des valeurs via une variable temporaire
			if(*tab[j]<*tab[i])
			{
				temp=tab[j];
				tab[j]=tab[i];
				tab[i]=temp;
			}
	//boucle de lecture des valeurs separees par 2 tabulations
	for(i=0;i<nb;++i)
		cout<<*tab[i]<<"\t";
    return 0;
}
