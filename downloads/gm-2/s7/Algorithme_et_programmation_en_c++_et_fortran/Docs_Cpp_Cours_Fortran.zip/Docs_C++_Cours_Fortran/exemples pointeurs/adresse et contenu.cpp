#include <iostream>

using namespace std;

int main () {
	//déclaration et intialisation de i et déclaration du pointeur adr_i
	int i=21, *adr_i;
	//affichage de i
	cout<<"i = "<<i<< " (la valeur de i)"<<endl;
	//affichage de l'adresse de i
	cout<<"&i = "<<&i<<" (l'adresse de i)"<<endl;
	//affectation de l'adresse de i au pointeur adr_i
	adr_i=&i;
	//affichage du contenu situé à l'adresse i
	cout<<"*adr_i = "<<*adr_i<<" (le contenu de l'adresse i)"<<endl;
	//affectation d'une nouvelle valeur au pointeur adr_i
	*adr_i=7;
	//affichage de la nouvelle valeur de i
	cout<<"i = "<<i<< " (la nouvelle valeur de i)"<<endl;
	//affichage de l'adresse de i
	cout<<"&i = "<<&i<<" (l'adresse de i est tjrs la meme)"<<endl;
    return 0;
}
