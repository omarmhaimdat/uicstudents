#include <iostream>

using namespace std;
//protype de la fonction fact
int fact(int);

int main () {
	//déclaration de nb
	int nb;
	//saisie de nb
	cout<<"Saisissez un nombre entier : ";
	cin>>nb;
	//affichage de la factorielle de nb
	cout<<nb<<"! = "<<fact(nb)<<endl;
    return 0;
}

//fonction fact
int fact(int n)
{
	//test si n est égal à 1 d, dans ce cas renvoie n
	if (n==1) return n;
	else
		//sinon calcule la factorielle via un appel récursif de la fonction fact
		return(n*fact(n-1));
}
