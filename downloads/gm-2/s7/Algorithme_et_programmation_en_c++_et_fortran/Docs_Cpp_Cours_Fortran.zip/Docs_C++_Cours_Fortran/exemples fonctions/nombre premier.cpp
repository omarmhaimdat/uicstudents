#include <iostream>
//appel de la bibliothèque cmath pour pouvoir utiliser la fonction sqrt (racine carrée)
#include <cmath>

using namespace std;

//prototype de la fonction, nécessaire au compilateur
int nbpremier(int);

//programme principal
int main () {
	//déclaration de x, le nombre entier à saisir
	int x;
	//saisie de x
	cout<<"Saisissez un nombre entier : ";
	cin>>x;
	//test et affichage du résultat via l'appel de la fonction nbpremier à laquelle on passe le nombre saisi
	if (nbpremier(x)==0) cout<<"Le nombre "<<x<<" n'est pas premier"<<endl;
		else cout<<"Le nombre "<<x<< " est premier"<<endl;
    return 0;
}

//fonction nbpremier pour tester la primalité d'un nombre, n est le nombre saisi
int nbpremier(int n)
{
	//déclaration de d, diviseur du nombre saisi
	int d;
	//déclaration et affectation de la racine carrée du nombre n à la variable racine_p
	float racine_n=sqrt(n);
	//test si n<2, dans ce cas n n'est pas premier on renvoie 0
	if(n<2) return 0;
	//test si n est égal à 2, dans ce cas n est premier on renvoie 1
	if(n==2) return 1;
	//test si le reste de n divisé par 2 est nul, dans ce cas n n'est pas premier on renvoie 0
	if(n%2==0) return 0;
	//boucle testant les diviseurs impairs de 3 à la racine carrée de n
	for (d=3; d<=racine_n; d+=2)
		//test: si le reste de n/d est nul, dans ce cas n n'est pas premier on renvoie 0
		if(n%d==0) return 0;
	return 1;
}




