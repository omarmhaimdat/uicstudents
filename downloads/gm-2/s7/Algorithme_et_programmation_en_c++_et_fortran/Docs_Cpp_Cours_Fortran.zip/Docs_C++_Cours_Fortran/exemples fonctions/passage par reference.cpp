#include <iostream>
using namespace std;
//fonction test
void test(int x, int& y){
    //affectation de 100 à x et 1000 à y
    x=100;
    y=1000;
}

int main () {
    //déclaration et affectation de i et j
    int i=99, j=999;
    //affichage de i et j
    //x est local et on lui affecte i qui vaut 100,
    //y est une réplique de j dont la valeur est 1000
    cout<<"i = "<<i<<" et j = "<<j<<endl;
    //la fonction test passe i par valeur à x et j par référence à y
    test(i,j);
    //affichage de i et j après appel de test
    //test affecte 100 à x sans manipuler i,
    //test affecte 100 à y et donc le réplique dans j
    //i est en lecture seule, j est en lecture-écriture
    cout<<"i = "<<i<<" et j = "<<j<<endl;
    return 0;
}
