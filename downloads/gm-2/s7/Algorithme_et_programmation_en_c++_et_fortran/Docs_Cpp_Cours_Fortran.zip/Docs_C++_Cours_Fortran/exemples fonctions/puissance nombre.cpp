#include <iostream>

using namespace std;

//déclaration de la fonction puissance sans argument
float puissance ()
{
	//déclaration des variables
	float nb, resultat=1.0; 
	int exp;
	//saisie du nombre
	cout<<"Saisissez un nombre : ";
	cin>>nb;
	//saisie de l'exposant
	cout<<"Saisissez un exposant : ";
	cin>>exp;	
	//boucle de calcul du résultat
	for (int i=1; i<=exp; ++i) resultat*=nb;
	//renvoie du reésultat
	return resultat;
}

//programme principal
int main () {
	//affichage du résultat via un appel de la fonction
	cout<<"Résultat : "<<puissance()<<endl;
    return 0;
}
