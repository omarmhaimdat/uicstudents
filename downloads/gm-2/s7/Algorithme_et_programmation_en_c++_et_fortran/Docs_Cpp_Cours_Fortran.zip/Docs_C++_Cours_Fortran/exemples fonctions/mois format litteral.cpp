#include <iostream>

using namespace std;
//prototype de la fonction
void date(int, int, int);

int main () {
	//déclaration des variables
	int jour, mois, annee;
	//saisie du jour, du mois et de l'année
	cout<<"saisissez en chiffres le jour : ";
	cin>>jour;
	cout<<"saisissez en chiffres le mois : ";
	cin>>mois;
	cout<<"saisissez en chiffres l'annee : ";
	cin>>annee;
	//appel de la fonction date
	date(jour, mois, annee);
}

//fonction date
void date(int j, int m, int a)
{
	//déclaration et i,itialisation d'un tableau des mois
	string tabmois[12]={"janvier","février","mars","avril","mai","juin","juillet","août","septembre","octobre","novembre","décembre"};
	//déclaration de ms qui contiendra le mois
	string ms;
	//boucle pour déterminer le mois
	for (int i=0; i<12; ++i)
		//teste le N° du mois 
		if (m==i+1) ms=tabmois[i];	
	//affichage de la date avec le mois en lettres
	cout<<j<<" "<<ms<<" "<<a<<endl;
}
