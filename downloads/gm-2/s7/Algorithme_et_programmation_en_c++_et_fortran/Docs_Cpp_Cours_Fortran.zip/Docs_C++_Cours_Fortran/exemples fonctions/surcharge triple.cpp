#include <iostream>

using namespace std;
//3 prototypes différents par leurs arguments de la fonction volume 
double volume(double);
double volume(double, double);
double volume(double, double , double);

int main () {
	//déclaration des varaibles
	int choix;
	double cote, rayon, hauteur, longueur, largeur, haut;
	//saisie du choix de calcul
    cout<<"Choisissez le volume à calculer (1-Cube, 2-Cône, 3-Parallélépipède) : ";
	cin>>choix;
	//sélection en fonction du choix
	switch (choix){
		case 1: 
			//saisie de la valeur du côté
			cout<<"Côté du cube : ";
			cin>>cote;
			//affichage et appel de la fonction volume
			cout<<"Le volume du cube est égal à : "<<volume(cote)<<endl;
			break;
		case 2:
			//saisie du rayon et de la hauteur du cône
			cout<<"Rayon du cône :";
			cin>>rayon;
			cout<<"Hauteur du cone : ";
			cin>>hauteur;
			//affichage et appel de la fonction volume
			cout<<"Le volume du cône est égal à : "<<volume(rayon, hauteur)<<endl;
			break;
		case 3:
			//saisie de la longueur, largeur et hauteur du parallélépipède
			cout<<"Longueur du parallélépipède : ";
			cin>>longueur;
			cout<<"Largeur du parallélépipède : ";
			cin>>largeur;
			cout<<"Hauteur du parallélépipède : ";
			cin>>haut;
			//affichage et appel de la fonction volume
			cout<<"Le volume du parallélépipède est égal à : "<<volume(longueur, largeur, haut)<<endl;
			break;
		default:
			//affichage d'une erreur en cas de mauvais choix
			cout<<"Erreur !!!"<<endl;
			break;
	}
    return 0;	
}

//fonction volume pour le calcul du volume du cube (1 argument)
double volume(double c)
{
	double v;
	v=c*c*c;
	return v;
}

//fonction volume pour le calcul du volume du cône (2 arguments)	
double volume(double r, double h1)
{
	double v;
	//déclaration de la constante PI
	const double PI=3.141592653589793;
	v=PI/3*r*r*h1;
	return v;
}

//fonction volume pour le calcul du volume du parallélépipède (3 arguments)	
double volume(double L, double l, double h2)
{
	double v;
	v=L*l*h2;
	return v;
}


