#include <iostream>
using namespace std;

int main ()
{
int fact(int n);

int p=4, q=6,r=10,s;
cout<<"Donner la valeur de s :" ;
cin>>s;
cout<<"p!= "<<fact(p)<<endl;
cout<<"q!= "<<fact(q)<<endl;
cout<<"r!= "<<fact(r)<<endl;
cout<<"s!= "<<fact(s)<<endl;
}

int fact(int n)
{ int i, F=1;
  if (n==0)
      return(1);
  else
      {
          for (i=1;i<=n;i++)
            F=F*i;
          return F;
      }
}
