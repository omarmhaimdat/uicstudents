#include <iostream>

using namespace std;
//déclaration d'une constante pour la taille maximale du tableau
const int nbval=25;

//prototypes des fonctions
void tri(int, float tableau[]);
void affiche(int, float tableau[]);

int main () {
	//déclaration des variables entière
	int nb;
	float tab[nbval];
	//saisie du nombre de valeurs à trier
	cout<<"Nombre de valeurs a trier (maxi : 25) : ";
	cin>>nb;
	//boucle de saisie des nombres
	for(int i=0;i<nb;++i)
	{
		cout<<"Saisissez un nombre : ";
		cin>>tab[i];
	}
	//appel de la fonction tri
	tri(nb, tab);
	//appel de la fonction affiche
	affiche(nb, tab);
	return 0;
}

//fonction tri
void tri(int nbr, float tableau[])
{
	float temp;
	//boucles de tri
	for(int i=0;i<nbr-1;++i)
		for (int j=i+1;j<nbr;++j)
			//permutation des valeurs via une variable temporaire
			if(tableau[j]<tableau[i])
			{
				temp=tableau[j];
				tableau[j]=tableau[i];
				tableau[i]=temp;
			}
	return;
}

//fonction affiche
void affiche(int n, float tableau[])
{
	//boucle de lecture des valeurs séparées par 2 tabulations
	for(int i=0;i<n;++i)
		cout<<tableau[i]<<"\t";
    return;
}


