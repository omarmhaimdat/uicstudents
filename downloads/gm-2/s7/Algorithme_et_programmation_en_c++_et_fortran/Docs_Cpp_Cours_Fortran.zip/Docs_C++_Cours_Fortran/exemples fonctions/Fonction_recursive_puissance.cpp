#include <iomanip>       // pour les "manipulateurs param�triques"
#include <iostream>
using namespace std ;

main()

{
 float puissance(float,int);
 int p;
 float y;
 cout<<"Donner y :";
 cin>>y;
 cout<<"Donner n :";
 cin>>p;
 cout<<y<<"^"<<p<<"="<<puissance(y,p)<<endl;
}

float puissance(float x,int n)
{
  if (n==0)
    return 1;
  else
    return(x*puissance(x,n-1));
}



