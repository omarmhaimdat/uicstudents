#include <iostream>

using namespace std;

//prototypes des fonctions
double add(double (*)(double), int);
double carre(double);
double cube(double);

int main () {
	int n;
	//saisie du nombre de valeurs à traiter
    cout<<"Nombre de valeurs à traiter : ";
	cin>>n;
	//affichage des deux sommes via l'appel des fonctions carre et cube suivant un nombre de valeurs à traiter n
	cout<<"Somme des carrés : "<<add(carre,n)<<endl;
	cout<<"Somme des cubes : "<<add(cube,n)<<endl;
	return 0;
}

//fonction add
//elle évalue la fonction sur laquelle pointe p
double add(double (*p)(double x), int y)
{
	double somme=0, nb;
	//boucle de calcul suivant un nombre d'itération égal à y
	for(int i=1;i<=y;++i)
	{
		//saisie d'un nombre
		cout<<"Saisissez un nombre : ";
		cin>>nb;
		//calcul de la somme cumulée
		somme+=(p)(nb);
	}
	return somme;
}

//fonction carre
double carre(double n1)
{
	double car;
	//calcul du carré
	car=n1*n1;
	//affichage du carré calculé
	cout<<"Carré de "<<n1<<" = "<<car<<endl;
	//retourne la valeur car
	return car;
}

//fonction cube
double cube(double n2)
{
	double cub;
	//calcul du cube
	cub=n2*n2*n2;
	//affichage du cube calculé
	cout<<"Cube de "<<n2<<" = "<<cub<<endl;
	//retourne la valeur cub
	return cub;
}
