#include <iostream>

using namespace std;

//prototype de la fonction inverse
double inverse(double);

int main () {
	double nb;
	//saisie d'un nombre
	cout<<"Saisissez un nombre : ";
	cin>>nb;
	//affichage de l'inverse via l'appel de la fonction inverse
	cout<<"L'inverse de "<<nb<<" est égal à "<<inverse(nb)<<endl;
	return 0;
}

//fonction inverse
double inverse(double x)
{
	//test si x est égal à 0
	if (x==0) 
	{
		//dans ce cas affiche un message d'erreur et termine le programme
		cout<<"Erreur - 0 n'a pas d'inverse !"<<endl;
		exit(0);
	}
	//retourne le résultat du calcul
	return 1.0/x;
}
