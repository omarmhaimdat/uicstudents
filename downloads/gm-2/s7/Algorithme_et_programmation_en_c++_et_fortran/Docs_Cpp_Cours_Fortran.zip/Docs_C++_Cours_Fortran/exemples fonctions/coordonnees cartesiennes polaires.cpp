#include <iostream>
//appel de la bibliothèque <cmath> pour sqrt et atan
#include<cmath>
using namespace std;
//déclaration de la constante PI
const double PI=3.1415926535897932385;
//déclaration du prototype de la fonction cartpol
void cartpol(double&, double&, double, double);
int main () {
	//déclaration des variables
	double x, y, r, a;
	//saisie de x et y
    cout<<"Saisissez x : ";
	cin>>x;
	cout<<"Saisissez y : ";
	cin>>y;
	//appel de la fonction cartpol
	cartpol(r, a, x, y);
	//affichage du résultat
	cout<<"Pour le couple de coordonnées cartésiennes (x,y) = ("<<x<<", "<<y<<")"<<endl;
	cout<<"le couple de coordonnées polaire (r, a) = ("<<r<<", "<<a<<")"<<endl;
    return 0;
}
//fonction cartpol
//r et a sont passés par référence car la fonction cartpol doit renvoyer 2 valeurs en sortie
void cartpol(double& r, double& a, double x, double y)
{
	//calcul du rayon r
	r=sqrt(x*x+y*y);
	//calcul de l'angle a
	if (x>0)
		if (y>=0) a=atan(y/x);
		else a=atan(y/x)+2*PI;
	else 
	if (x==0)
		if (y>0) a=PI/2;
		else 
			if (y<0) a=3*PI/2;
	a=atan(y/x)+PI;
}
				
