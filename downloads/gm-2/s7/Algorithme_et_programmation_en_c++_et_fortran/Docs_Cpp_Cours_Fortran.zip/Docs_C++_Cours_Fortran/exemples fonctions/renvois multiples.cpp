#include <iostream>

using namespace std;

//prototype de la fonction sphere
//volume, surface et circonférence seront passés par référence, rayon par valeur
void sphere(double&, double&, double&, double);

int main () {
	//déclaration des variables
    double r, v, s, c;
	//saisie du rayon
	cout<<"Saisissez le rayon : ";
	cin>>r;
	//appel de la fonction
	sphere(v, s, c, r);
	//affichage des résultats : volume, surface et circonférence
	cout<<"Volume : "<<v<<endl;
	cout<<"Surface : "<<s<<endl;
	cout<<"Circonférence : "<<c<<endl;
    return 0;
}

//fonction sphere
void sphere(double& volume, double& surface, double& circonference, double rayon)
{
	//déclaration et initialisation de la constante PI
	const double PI=3.141592653589793;
	//calcul du volume, de la surface et de la circonférence qui seront récupérées par référence
	//le rayon, passé par valeur, est seulement utile au calculs
	volume=4.0/3.0*PI*rayon*rayon*rayon;
	surface=4*PI*rayon*rayon;
	circonference=2*PI*rayon;
}


	

