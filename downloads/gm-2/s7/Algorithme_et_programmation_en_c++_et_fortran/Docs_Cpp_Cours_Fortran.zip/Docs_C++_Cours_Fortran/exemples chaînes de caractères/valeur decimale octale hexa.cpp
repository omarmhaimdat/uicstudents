#include <iostream>
using namespace std;
int main () {
    //déclaration de la chaîne majuscule
    char majminchif[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    //affectation à taillemaj de la taille de la chaîne majuscule
    int taillemaj=sizeof(majminchif);
    //affichage de la taille de la chaîne
    cout<<"Taille de la chaîne : "<<taillemaj<<endl;
    //boucle d'affichage des différentes valeurs : décimale, octal, et hexadécimal de chacun des caractères de la chaîne majminchif
    for (int i=0; i<taillemaj; ++i)
    {
        cout<<"------------------------"<<endl;
        cout<<majminchif[i]<<" (en décimal) -> "<<int(majminchif[i])<<endl;
        cout<<majminchif[i]<<" (en octal) -> "<<oct<<int(majminchif[i])<<endl;
        cout<<majminchif[i]<<" (en hexadécimal) -> "<<hex<<int(majminchif[i])<<endl;
    }
    return 0;
}

