#include <iostream>
using namespace std ;
main()
{
char * ad1 ;
ad1 = "bonjour" ;   // place dans la variable ad1 l�adresse de la chaine constante"bonjour"
cout << ad1 << "\n" ;  // d�afficher la valeur de la cha�ne dont l�adresse figure dans ad1, c�est-�-dire en l�occurrence "bonjour".
ad1 = "monsieur" ;    // place l�adresse de la cha�ne constante "monsieur" dans ad1
cout << ad1 ;   // affiche la valeur de la cha�ne ayant maintenant l�adresse contenue dans ad1, c�est-�-dire "monsieur".
}

//  On aurait obtenu plus simplement le m�me r�sultat en �crivant :
//  cout << "bonjour\nmonsieur" ;
