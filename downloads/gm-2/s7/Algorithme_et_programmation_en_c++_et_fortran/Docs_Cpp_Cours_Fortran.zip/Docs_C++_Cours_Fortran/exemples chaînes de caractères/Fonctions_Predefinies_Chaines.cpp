#include <iostream>
#include <cstring>
#include <iomanip>
using namespace std ;
main()
{ char ch1[20], ch2[20],ch3[20];


cout << "donnez votre ch1 et ch2 : " ;
cin >>setw(20) >>ch1 >>setw(20)>> ch2 ;
cout<<"ch1="<<ch1<<" et ch2="<<ch2<<endl;

if (strcmp(ch1,ch2)<0)
  cout<<"La chaine ch1 arrive avant ch2 au sens de l'ordre d�fini par le code des caracteres"<<endl;
else
  if (strcmp(ch1,ch2)>0)
    cout<<"La chaine ch1 arrive apres ch2 au sens de l'ordre d�fini par le code des caracteres"<<endl;
  else
    cout<<"les 2 chaines sont identiques"<<endl;

strcpy(ch3,ch1);  // copie ch1 dans ch3;
cout << "La valeur de ch3 est : " << ch3<<endl ;
cout << "La longueur de ch1 est : " << strlen(ch1)<<endl ;
strcat(ch1,ch2);    //concat�ne la cha�ne nom2 avec la cha�ne nom1
cout << "La nouvelle valeur de ch1 est : " << ch1<<endl ;


}
