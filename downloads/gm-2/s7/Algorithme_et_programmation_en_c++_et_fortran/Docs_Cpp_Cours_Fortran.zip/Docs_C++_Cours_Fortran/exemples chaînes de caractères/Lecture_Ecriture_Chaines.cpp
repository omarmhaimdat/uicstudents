#include <iostream>
#include <iomanip>
using namespace std ;
main()
{ char nom[20], prenom[20],ville[25];
//char * ville = new char [25] ;
/* le nom fourni par l�utilisateur ne doit pas contenir plus de 19 caract�res. Le dernier caract�re est '\0'
qui marque la fin de la chaine  */
cout << "quelle est votre ville : " ;
cin >> ville ;
cout << "donnez votre nom :";
cin >>nom;
cout << "donnez votre Pr�nom :";
cin>>setw(6)>> prenom ;
cout << "bonjour cher " << prenom << " "<< nom << " qui habitez a " << ville ;
//delete ville; //lib�re l'espace m�moire occup� par la cah�ne ville.
}
