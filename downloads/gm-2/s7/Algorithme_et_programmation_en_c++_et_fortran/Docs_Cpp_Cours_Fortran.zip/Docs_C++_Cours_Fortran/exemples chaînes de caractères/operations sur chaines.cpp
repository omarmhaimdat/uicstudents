#include <iostream>
#include <string.h>

using namespace std;
int main () {
    //déclaration des variables texte1, texte2 et texte3
    char texte1[]="Il etait un";
    char texte2[]=" petit navire";
    char texte3[25];
    char msg[]="abcdefghjiklfmpoi";

    //affichage des résultats et utilisation des fonctions
    cout<<"texte1 + texte2 : "<<strcat(texte1,texte2)<<endl;
    cout<<"texte3 : "<<strcpy(texte3,texte1)<<endl;
    cout<<"Taille de la chaine texte1 : "<<strlen(texte1)<<endl;
    cout<<"Quel texte commence à partir de la lettre 'v' : "<<strchr(texte1,'v')<<endl;
    cout<<"Sous-chaine commençant par f :"<<strchr(msg,'f');
    return 0;
}


