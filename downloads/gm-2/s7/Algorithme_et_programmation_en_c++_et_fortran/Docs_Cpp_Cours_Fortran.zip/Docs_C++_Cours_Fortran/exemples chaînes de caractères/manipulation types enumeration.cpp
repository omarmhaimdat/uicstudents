#include <iostream>
using namespace std;
//création des types énumérations
enum jour{lundi, mardi, mercredi, jeudi, vendredi, 
	samedi, dimanche};
enum couleur{brun, cyan, rouge, vert, bleu, magenta, 
	jaune, noir};
enum logique{vrai=1, faux=0};
int main () {
    //déclarations
    jour j1, j2;
    j1=mardi;
    j2=mardi;
    couleur tomate=rouge;
    couleur ciel=bleu;
    logique ok=vrai;
    //test comparatif entre les variables j1 et j2 et affiche le résultat
    if (j1==j2) cout<<"Jours identiques"<<endl;
    //test si la variable tomate a pour valeur d'énumérateur 2 et affiche le résultat
    if(tomate==2) cout<<"Une tomate est rouge"<<endl;
    //test si la variable ciel a pour valeur d'énumérateur 5 et affiche le résultat
    if(ciel==5) cout<<"Un canari est jaune"; 
	else cout<<"Pas toujours"<<endl;
    //affiche la valeur de la variable ok
    cout<<"Valeur de ok : "<<ok<<endl;
    return 0;
}

