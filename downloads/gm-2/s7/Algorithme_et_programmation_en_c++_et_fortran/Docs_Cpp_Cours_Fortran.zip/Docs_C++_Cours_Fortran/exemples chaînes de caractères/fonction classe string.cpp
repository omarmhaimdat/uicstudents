#include <iostream>
#include <string>
using namespace std;
int main () {
    //déclarations des variables
    string texte1="Il était un tout petit petit navire";
    string mot1("petit");
    string mot2("enfant");
    int i;
    //recherche la position du mot 'était' dans texte1
    cout<<"Le mot 'était' est placé en "<<texte1.find("était")<<"ième position dans la chaîne"<<endl;
    //recherche la position de la variable mot1 dans texte1
    cout<<"Le mot 'petit ' est placé en "<<texte1.find(mot1)<<"ième position dans la chaîne"<<endl;
    //recherche le dernier mot 'petit' dans texte1
    cout<<"Le dernier mot 'petit' est placé en "<<texte1.rfind(mot1)<<"ième position dans la chaîne"<<endl;
    //recherche la première occurence d'un caractère d'une chaîne 'bcade'
    cout<<"La première occurence d'un caractère de la suite 'bcade' est placée en"<<texte1.find_first_of("bcade")<<"ième position dans la chaîne"<<endl;
    //recherche la dernière occurence d'un caractère d'une chaîne 'bcade'
    cout<<"La dernière occurence d'un caractère de la suite 'bcade' est placé en"<<texte1.find_last_of("bcade")<<"ième position dans la chaîne"<<endl;
    //recherche la première occurence d'un caractère qui n'appartient pas à la chaîne 'bcade'
    cout<<"La première occurence d'un caractère qui n'appartient pas à la suite 'bcade' est placé en"<<texte1.find_first_not_of("bcade")<<"ième position dans la chaîne"<<endl;
    //recherche la dernière occurence d'un caractère qui n'appartient pas à la chaîne 'bcade'
    cout<<"La dernière occurence d'un caractère qui n'appartient pas à la suite 'bcade' est placé en"<<texte1.find_last_not_of("bcade")<<"ième position dans la chaîne"<<endl;
    //affectation du résultat de la recherche à la variable i
    i=texte1.find("était");
    //affichage de i
    cout<<"Le mot 'était' est placé en position N° : "<<i<<endl;
    //insertion de mot1 dans texte1
    cout<<"La nouvelle chaîne texte1 : "<<texte1.insert(18, mot1)<<endl;
    //remplacement du mot 'navire' par le mot 'enfant'
    cout<<"Après remplacement la chaîne texte1 devient : "<<texte1.replace(36, 6, mot2)<<endl;
    //suppression du mot 'petit' dans texte1
    cout<<"Après suppression la chaîne texte1 devient : "<<texte1.erase(23, 6)<<endl;
    //affiche la longueur de la chaîne texte1
    cout<<"La longueur de texte1 est : "<<texte1.length()<<endl;
    return 0;
	}


