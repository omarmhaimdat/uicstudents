#include <iostream>
#include <string>
using namespace std;
int main () {
    //déclaration des variables texte1, et texte3
	string texte1, texte3;
    //affectation
    texte1="Il était un";
    //affectation et concaténation avec l'opérateur conventionnel
    texte1+=" petit navire";
    texte3=texte1;
    //affichage des résultats
    cout<<"texte1 : "<<texte1<<endl;
    cout<<"texte3 : "<<texte3<<endl;
    return 0;
}

