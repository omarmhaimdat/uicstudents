2)
//pour tous les noeuds et les relationships
MATCH (n) RETURN COUNT(n)
MATCH ()-[r]-() RETURN COUNT(r)
// pour les categories de noeuds et relationships
MATCH (n1:Person) RETURN COUNT(n1)
MATCH (n2:Movie) RETURN COUNT(n2)
MATCH ()-[r:ACTED_IN]->() RETURN COUNT(r)
MATCH ()-[r:DIRECTED]->() RETURN COUNT(r)

3) on peut le faire de 2 manieres
MATCH (tom{name:"Tom Hanks"}) RETURN tom
MATCH (tom:Person) WHERE tom.name="Tom Hanks" RETURN tom

4)
MATCH (film{title:"Cloud Atlas"}) RETURN film
MATCH (film:Movie) WHERE film.title="Cloud Atlas" RETURN film

5)
MATCH (n:Person) return n.name LIMIT 10
// la commande ci-dessous permet de retourner 10 personnes par ordre decroissant de leur annee de naissance
MATCH (n:Person) return n.name AS nom, n.born AS annee ORDER BY n.name LIMIT 10

6)
match (films:Movie) WHERE films.released>=1990 AND films.released<2000 return films.title AS annee1990s

7)
match (v:Person)-[]->(t:Movie) where v.name="Tom Hanks" return t

8)
//Sajid
match (v:Person)-[:DIRECTED]->(t:Movie) where t.title="Cloud Atlas" return v
//Meryem T
match (p:Person)-[r:DIRECTED]->(m:Movie) where m.title="Cloud Atlas" return p

9)
//Sajid
match (p:Person)-[:ACTED_IN]->(m:Movie)<-[:ACTED_IN]-(tom:Person) where tom.name="Tom Hanks" return p.name,m.title
Meryem T
match (tom:Person{name:"Tom Hanks"})-[:ACTED_IN]->(m:Movie)<-[:ACTED_IN]-(p:Person)  return p.name AS actors, m.title AS film

10)
match (p:Person)-[r]->(:Movie{title:"Cloud Atlas"}) return p.name as name, type(r) as rule ORDER BY rule

11)
match (kevin:Person{name:"Kevin Bacon"})-[*1..4]-(n) return n

12)
match p=shortestPath((:Person{name:"Kevin Bacon"})-[*]-(:Person{name:"Meg Ryan"})) return p
